package principal;

public interface CanRead {
	
	void leePagina(boolean silenciosamente);

}
